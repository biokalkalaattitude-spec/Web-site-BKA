# Bio Kalkala Attitude — site web production

## Contenu
- `index.html` : site autonome, responsive et prêt à être hébergé.
- `assets/` : logo et photos fournies dans la maquette originale.

## Mise en ligne
Téléverser `index.html` et le dossier `assets/` à la racine du domaine.

## À vérifier avant publication
1. Remplacer `https://biokalkalaattitude.com/` dans `canonical` et le Schema.org par le domaine réel si différent.
2. Vérifier l'adresse e-mail et les numéros de téléphone.
3. Ajouter les identifiants Google Analytics / Meta Pixel si utilisés.
4. Créer `robots.txt` et `sitemap.xml` pour le domaine final.
5. Tester les boutons WhatsApp et appel sur Android/iPhone.
